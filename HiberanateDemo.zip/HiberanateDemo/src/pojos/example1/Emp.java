package pojos.example1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;
import org.hibernate.annotations.NamedQueries;

@NamedQueries(
		
		{
			@NamedQuery(name="empwithbasicmorethanlimit", query="from Emp As E where E.basic>=:limit"),
			@NamedQuery(name="empwithbasiclessthanlimit", query="from Emp As E where E.basic<=:limit")
		}
	)


@Entity
@Table(name="TestEmps")
public class Emp {
	
	@Id
	@Column(name="eid")
	private int empId;
	@Column(name="empName")
	private String empName;
	@Column(name="basic")
	private double basic;
	
	public Emp()
	{
		
	}

	public Emp(int empId, String empName, double basic) {
		
		this.empId = empId;
		this.empName = empName;
		this.basic = basic;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", basic="
				+ basic + "]";
	}
	
	 
	

}
