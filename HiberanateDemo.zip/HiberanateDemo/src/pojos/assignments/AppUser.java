package pojos.assignments;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import pojos.example3.many2many.Artist;
import pojos.example3.many2many.Movie;

@NamedQueries(
		
		{
			@NamedQuery(name="appuser", query="from AppUser As A where A.userId=:userId"),
		}
	)

@Entity
@Table(name="appuser")
public class AppUser implements Comparable<AppUser> {
	
	@Id
	private long userId;
	private String username;
	private String password;
	
	@ManyToMany(cascade={CascadeType.ALL})
	@JoinTable(name="appusercred",
	joinColumns={@JoinColumn(name="uid")},
	inverseJoinColumns={@JoinColumn(name="cid")})
	private Set<Credential> credentials;
	
	public AppUser()
	{
		
	}
	
	public AppUser(long userId, String username, String password) {
		this.userId = userId;
		this.username = username;
		this.password = password;
	}
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Credential> getCredentials() {
		return credentials;
	}

	public void setCredentials(Set<Credential> credentials) {
		this.credentials = credentials;
	}

	@Override
	public String toString() {
		return "AppUser [userId=" + userId + ", username=" + username + ", password=" + password + ",credentials=" + credentials
				+ "]";
	}

	//@Override
	public int compareTo(AppUser o) {
		
		return (int) (this.userId-o.userId);
	}

}
