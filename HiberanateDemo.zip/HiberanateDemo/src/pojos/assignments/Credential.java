package pojos.assignments;

import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="credential")
public class Credential implements Comparable<Credential>{
	
	@Id
	private long credId;
	private String resource;
	boolean isAllowed;
	
	@ManyToMany(mappedBy="credentials")
	private Set<AppUser> appUsers;
	
	public Credential()
	{
		
	}

	public Credential(long credId, String resource, boolean isAllowed, Set<AppUser> appUsers) {
		this.credId = credId;
		this.resource = resource;
		this.isAllowed = isAllowed;
		this.appUsers = appUsers;
	}

	public long getCredId() {
		return credId;
	}

	public void setCredId(long credId) {
		this.credId = credId;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public boolean isAllowed() {
		return isAllowed;
	}

	public void setAllowed(boolean isAllowed) {
		this.isAllowed = isAllowed;
	}

	public Set<AppUser> getAppUsers() {
		return appUsers;
	}

	public void setAppUsers(Set<AppUser> appUsers) {
		this.appUsers = appUsers;
	}

	@Override
	public String toString() {
		return "Credential [credId=" + credId + ", resource=" + resource +", isAllowed=" + isAllowed +"]";
	}

	//@Override
	public int compareTo(Credential arg0) {
		
		return (int) (this.credId-arg0.credId);
	}
	
	

}
