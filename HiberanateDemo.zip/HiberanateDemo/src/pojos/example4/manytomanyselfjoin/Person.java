package pojos.example4.manytomanyselfjoin;

import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="PersonSelfjoined")
public class Person implements Comparable<Person> {
	
	@Id
	private int pId;
	private String pName;
	
	@ManyToMany
	@JoinColumn(name="friendId")
	private Person superior;

	@ManyToMany(cascade=CascadeType.ALL, mappedBy="superior")
	private Set<Person> friends; 
	
	public Person()
	{
		
	}

	public Person(int pId, String pName, Person superior) {
		
		this.pId = pId;
		this.pName = pName;
		//this.superior = superior;
		this.friends = new TreeSet<Person>();
	}


	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	@Override
	public String toString() {
		return "Person [pId=" + pId + ", pName=" + pName + "]";
	}

	public Person getSuperior() {
		return superior;
	}

	public void setSuperior(Person superior) {
		this.superior = superior;
	}

	public Set<Person> getFriends() {
		return friends;
	}

	public void setSubordinates(Set<Person> subordinates) {
		this.friends = friends;
	}
	
	//@Override
		public int compareTo(Person arg0) {
			// TODO Auto-generated method stub
			return (this.pId<arg0.pId?-1:(this.pId>arg0.pId?1:0));
		}

}
