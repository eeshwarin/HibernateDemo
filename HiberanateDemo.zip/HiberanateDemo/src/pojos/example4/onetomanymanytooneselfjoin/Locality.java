package pojos.example4.onetomanymanytooneselfjoin;

import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import pojos.example3.one2many.Student;


@Entity
@Table(name="LocalitySelfjoined")
public class Locality implements Comparable<Locality> {
	
	@Id
	private int locId;
	private String locName;
	private String locType;
	
	@ManyToOne
	@JoinColumn(name="contId")
	private Locality superior;
	
	public String getLocType() {
		return locType;
	}

	public void setLocType(String locType) {
		this.locType = locType;
	}

	@OneToMany(cascade=CascadeType.ALL, mappedBy="superior")
	private Set<Locality> subordinates; 
	
	public Locality()
	{
		
	}

	public Locality(int locId, String locName, String locType, Locality superior) {
		
		this.locId = locId;
		this.locName = locName;
		this.locType = locType;
		this.superior = superior;
		this.subordinates = new TreeSet<Locality>();
	}

	

	public int getLocId() {
		return locId;
	}

	public void setLocId(int locId) {
		this.locId = locId;
	}

	public String getLocName() {
		return locName;
	}

	public void setLocName(String locName) {
		this.locName = locName;
	}

	@Override
	public String toString() {
		return "Locality [locId=" + locId + ", locName=" + locName + "]";
	}

	public Locality getSuperior() {
		return superior;
	}

	public void setSuperior(Locality superior) {
		this.superior = superior;
	}

	public Set<Locality> getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(Set<Locality> subordinates) {
		this.subordinates = subordinates;
	}
	
	//@Override
		public int compareTo(Locality arg0) {
			// TODO Auto-generated method stub
			return (this.locId<arg0.locId?-1:(this.locId>arg0.locId?1:0));
		}

}
