package pojos.example4.onetomanymanytooneselfjoin;

import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import pojos.example3.one2many.Student;



@Entity
@Table(name="EmpSelfjoined")
public class Employee implements Comparable<Employee> {
	
	@Id
	private int empId;
	private String empName;
	
	@ManyToOne
	@JoinColumn(name="mgrId")
	private Employee superior;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="superior")
	private Set<Employee> subordinates; 
	
	public Employee()
	{
		
	}

	public Employee(int empId, String empName,Employee superior) {
		
		this.empId = empId;
		this.empName = empName;
		this.superior = superior;
		this.subordinates = new TreeSet<Employee>();
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + "]";
	}

	public Employee getSuperior() {
		return superior;
	}

	public void setSuperior(Employee superior) {
		this.superior = superior;
	}

	public Set<Employee> getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(Set<Employee> subordinates) {
		this.subordinates = subordinates;
	}
	
	//@Override
		public int compareTo(Employee arg0) {
			// TODO Auto-generated method stub
			return (this.empId<arg0.empId?-1:(this.empId>arg0.empId?1:0));
		}

}
