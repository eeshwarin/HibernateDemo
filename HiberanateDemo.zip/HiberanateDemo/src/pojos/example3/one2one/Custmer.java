package pojos.example3.one2one;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customerdet")
public class Custmer {
	@Id
	private String aadhar;
	private String name;
	@OneToOne(mappedBy="custmer", cascade= CascadeType.ALL)
	private BankAccount account;
	
	public Custmer()
	{
		
	}

	public Custmer(String aadhar, String name, BankAccount account) {
		super();
		this.aadhar = aadhar;
		this.name = name;
		this.account = account;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BankAccount getAccount() {
		return account;
	}

	public void setAccount(BankAccount account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Custmer [aadhar=" + aadhar + ", name=" + name + ", account="
				+ account + "]";
	}
	
	

}
