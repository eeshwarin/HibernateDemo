package pojos.example3.one2one;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="bankaccountdet")
public class BankAccount {
	
	//111Previously aadhar was the primary key for bankaccountet and foreign key for customerdet and now accno is the primary key
	/*@Id
	@Column(name="aadhar")
	@GeneratedValue(generator="myGen")
	@GenericGenerator(name="myGen",strategy="foreign", parameters={@Parameter(name="property", value="custmer")})
	private String aadhar;*/
	
	//Now accno is the primary key
	@Id
	private String accno;
	
	@OneToOne
	//uncomment below for 111 and comment @JoinColumn
	//@PrimaryKeyJoinColumn
	@JoinColumn(name="aadhar")
	private Custmer custmer;
	
	public BankAccount()
	{
		
	}

	public BankAccount(String accno) {
		super();
		//this.aadhar = aadhar;
		this.accno = accno;
	}

	/*public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}*/

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	@Override
	public String toString() {
		//return "BankAccount [aadhar=" + aadhar + ", accno=" + accno + "]";
		return "BankAccount [accno=" + accno + "]";
	}

	public Custmer getCustmer() {
		return custmer;
	}

	public void setCustmer(Custmer custmer) {
		this.custmer = custmer;
	}
	

}
