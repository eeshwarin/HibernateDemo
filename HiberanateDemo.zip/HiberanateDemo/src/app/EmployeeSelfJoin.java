package app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example4.onetomanymanytooneselfjoin.Employee;
import pojos.example4.onetomanymanytooneselfjoin.Locality;

public class EmployeeSelfJoin {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Locality.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		
		//SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Locality topLoc = new Locality(1, "Asia", "County", null);
		Locality loc1 = new Locality(2, "Africa", "County", null);
		Locality loc2 = new Locality(3, "India", "Country", topLoc);
		Locality loc3 = new Locality(4, "Karnataka", "State", loc2);
		
		topLoc.getSubordinates().add(loc1);
		topLoc.getSubordinates().add(loc2);
		topLoc.getSubordinates().add(loc3);
		
		session.saveOrUpdate(topLoc);
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
