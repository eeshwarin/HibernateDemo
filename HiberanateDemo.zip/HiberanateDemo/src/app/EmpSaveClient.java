package app;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example1.Emp;

public class EmpSaveClient {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(pojos.example1.Emp.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		//SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		//Emp e1 = new Emp(432,"dharmendar",20000.00);for rollback
		Emp e1 = new Emp(234,"dharmendar",20000.00);
		Emp e2 = new Emp(456,"rajesh",80000.00);
		Emp e3 = new Emp(786,"kishore",15000.00);
		
		try{
		session.saveOrUpdate(e1);
		//session.update(e1); for rollback
		session.saveOrUpdate(e2);
		session.saveOrUpdate(e3);
		tr.commit();
		System.out.println("Saved Sucessfully");
		}catch(Exception e){
			tr.rollback();
		}finally{
		session.close();
		//session.flush();
		
		}
		
		

	}

}
