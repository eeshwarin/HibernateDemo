package app;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example1.Emp;

public class EmpNamedQuery {
	public static void main(String ...args){
		Configuration conf= new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		
		conf.addAnnotatedClass(pojos.example1.Emp.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		
		
		Query qry1 = session.getNamedQuery("empwithbasicmorethanlimit");
		qry1.setParameter("limit", 30000.0);
		
		List emps = qry1.list();
		
		for(Emp e :(List<Emp>)emps)
		{
			System.out.println(e);
		}
		
		
		Query qry2 = session.getNamedQuery("empwithbasiclessthanlimit");
		qry2.setParameter("limit", 30000.0);
		
		List emps2 = qry2.list();
		
		for(Emp e :(List<Emp>)emps2)
		{
			System.out.println(e);
		}
		
		tx.commit();
		session.close();
		
	}

}
