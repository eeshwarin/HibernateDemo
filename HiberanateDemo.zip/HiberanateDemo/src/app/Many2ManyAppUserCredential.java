package app;
import java.util.List;
import java.util.TreeSet;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.assignments.AppUser;
import pojos.assignments.Credential;
import pojos.example1.Emp;

public class Many2ManyAppUserCredential {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(AppUser.class);
		conf.addAnnotatedClass(Credential.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();

		
		/*Credential c1 = new Credential(1,"aaa", true, new TreeSet<AppUser>());
		Credential c2 = new Credential(2,"bbb", false, new TreeSet<AppUser>());
		
		AppUser a1 = new AppUser(1,"ccc", "pass1");
		AppUser a2 = new AppUser(2,"ddd", "pass2");
		AppUser a3 = new AppUser(3,"eee", "pass3");
		
		c1.getAppUsers().add(a1);
		c2.getAppUsers().add(a2);
		c2.getAppUsers().add(a3);
		
		a1.setCredentials(new TreeSet<Credential>());
		a2.setCredentials(new TreeSet<Credential>());
		a3.setCredentials(new TreeSet<Credential>());
		
		a1.getCredentials().add(c1);
		a2.getCredentials().add(c2);
		a3.getCredentials().add(c1);
		a3.getCredentials().add(c2);
		
		session.saveOrUpdate(a1);
		session.saveOrUpdate(a2);
		session.saveOrUpdate(a3);*/
		
		
		Query qry1 = session.getNamedQuery("appuser");
		//qry1.setLong("userId", 1);
		qry1.setParameter("userId", 1l);
		
		List appUserList = qry1.list();
		
		for(AppUser e :(List<AppUser>)appUserList)
		{
			System.out.println(e.getUsername());
		}
		
		
		
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
