package app;

import java.util.TreeSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example3.one2many.Course;
import pojos.example3.one2many.Student;

public class One2ManyMany2OneSaveClient {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Course.class);
		conf.addAnnotatedClass(Student.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		
		//SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Course mca = new Course(1,"MCA",null);
		Course mba = new Course(2,"MBA",null);
		
		TreeSet <Student> mbaStudents = new TreeSet<Student>();
		TreeSet <Student> mcaStudents = new TreeSet<Student>();
		
		mbaStudents.add(new Student(123,"Rahul",mba));
		mbaStudents.add(new Student(456,"Kishore",mba));
		mbaStudents.add(new Student(789,"Suresh",mba));
		
		mcaStudents.add(new Student(147,"Rajesh",mca));
		mcaStudents.add(new Student(258,"Ram",mca));
		mcaStudents.add(new Student(963,"Narendra",mca));
		
		mca.setStudents(mcaStudents);
		mba.setStudents(mbaStudents);
		
		session.saveOrUpdate(mca);
		session.saveOrUpdate(mba);
		
		
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
