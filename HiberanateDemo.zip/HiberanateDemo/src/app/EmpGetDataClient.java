package app;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class EmpGetDataClient {
	public static void main(String ...args){
		Configuration conf= new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		
		conf.addAnnotatedClass(pojos.example1.Emp.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		//Query qry= session.createQuery("from pojos.example1.Emp");
		//Query qry= session.createQuery("from pojos.example1.Emp AS e");
		//Query qry= session.createQuery("Select e.empName from Emp e"); //casting required
		//Query qry= session.createQuery("from Emp As E where E.basic>=1000");
		//Query qry= session.createQuery("from Emp As E order by E.basic desc");
		/*Query qry = session.createQuery("from Emp As E where E.basic>=:limit");
		qry.setParameter("limit", 1000.0);*/
		
		Query qry = session.createQuery("update Emp As E set E.basic=:salary where E.empId=:id");
		qry.setParameter("salary", 60000.0);
		qry.setParameter("id", 786);
		int resultcount = qry.executeUpdate();
		System.out.println(resultcount+" row(s) updated");
		/*List emps = qry.list();
		
		for(Emp e :(List<Emp>)emps)
		{
			System.out.println(e);
		}*/
		
		tx.commit();
		session.close();
		
	}

}
