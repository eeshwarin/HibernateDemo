package app;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import pojos.example1.Emp;

public class EmpLogicalExpressionAndOr {
	public static void main(String ...args){
		Configuration conf= new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		
		conf.addAnnotatedClass(pojos.example1.Emp.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Emp.class);
		Criterion salary = Restrictions.gt("basic", 10000.0);
		Criterion name = Restrictions.like("empName", "dh%");
		
		//LogicalExpression ex = Restrictions.and(name, salary);
		LogicalExpression ex = Restrictions.or(salary, name);
		cr.add(ex);
		
		
		List emps2 = cr.list();
		
		for(Emp e :(List<Emp>)emps2)
		{
			System.out.println(e);
		}
		
		tx.commit();
		session.close();
		
	}

}
