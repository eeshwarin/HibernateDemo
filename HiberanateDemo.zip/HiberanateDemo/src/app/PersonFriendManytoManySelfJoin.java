package app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example4.manytomanyselfjoin.Person;
import pojos.example4.onetomanymanytooneselfjoin.Locality;

public class PersonFriendManytoManySelfJoin {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Person.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Person person = new Person(1, "Krishna", null);
		Person p1 = new Person(2, "Ram", person);
		Person p2 = new Person(3, "Sri", p1);
		Person p3 = new Person(4, "Shyam", p2);
		
		person.getFriends().add(p1);
		person.getFriends().add(p2);
		person.getFriends().add(p3);
		
		person.setSuperior(p1);
		//person.setSuperior(p2);
		//person.setSuperior(p3);
		
		session.saveOrUpdate(person);
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
