package app;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import pojos.example1.Emp;

public class EmpGetSingleRecordClient {
	public static void main(String ...args){
		Configuration cfg= new Configuration();
		cfg.configure("conf/hibernate.cfg.xml");
		cfg.addAnnotatedClass(pojos.example1.Emp.class);
		SessionFactory sf= cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//Emp e=(Emp)session.get(pojos.example1.Emp.class,234);
		//Emp e=(Emp)session.load(pojos.example1.Emp.class,234);
		//System.out.println("Emp No : "+e.getEmpName());
		Emp e1 = (Emp)session.load(pojos.example1.Emp.class, 234);
		session.lock(e1, LockMode.UPGRADE);		
		System.out.println(e1);
		System.out.println("We Are Done");
		try
		{
			Thread.sleep(8000);
		}catch(InterruptedException e){}
		session.close();
		System.out.println("Lock Released");
		
	}

}
