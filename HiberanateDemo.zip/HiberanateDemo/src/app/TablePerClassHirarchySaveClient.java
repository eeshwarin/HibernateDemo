package app;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojos.example2.Emp;
import pojos.example2.Manager;
import pojos.example2.ContractEmp;

public class TablePerClassHirarchySaveClient {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Emp.class);
		conf.addAnnotatedClass(Manager.class);
		conf.addAnnotatedClass(ContractEmp.class);
		
		SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Emp e1 = new Emp(234,"dharmendar",20000.00);
		Manager m1= new Manager(456,"Raju",15000.00,800.00);
		ContractEmp c1= new ContractEmp(789,"Gopal",75000.00,5);
		
		session.saveOrUpdate(e1);
		session.saveOrUpdate(m1);
		session.saveOrUpdate(c1);
		
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
