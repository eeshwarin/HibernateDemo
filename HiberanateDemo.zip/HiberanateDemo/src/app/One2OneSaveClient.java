package app;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojos.example3.one2one.BankAccount;
import pojos.example3.one2one.Custmer;

public class One2OneSaveClient {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Custmer.class);
		conf.addAnnotatedClass(BankAccount.class);
		
		SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		BankAccount a1= new BankAccount();
		a1.setAccno("12345");
		//a1.setAadhar("80808");
		
		Custmer c1= new Custmer("80808","Rahul",a1);
		a1.setCustmer(c1);
		
		
		session.save(c1);
				
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
