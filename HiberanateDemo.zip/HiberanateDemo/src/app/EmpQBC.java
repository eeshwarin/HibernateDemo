package app;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import pojos.example1.Emp;

public class EmpQBC {
	public static void main(String ...args){
		Configuration conf= new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		
		conf.addAnnotatedClass(pojos.example1.Emp.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Emp.class);
		cr.add(Restrictions.gt("basic", 10000.0));
		
		
		
		List emps2 = cr.list();
		
		for(Emp e :(List<Emp>)emps2)
		{
			System.out.println(e);
		}
		
		tx.commit();
		session.close();
		
	}

}
