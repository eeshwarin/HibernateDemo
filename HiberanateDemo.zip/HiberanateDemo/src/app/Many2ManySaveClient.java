package app;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import pojos.example3.many2many.Movie;
import pojos.example3.many2many.Artist;
import pojos.example3.one2many.Course;
import pojos.example3.one2many.Student;

import java.util.Set;
import java.util.TreeSet;

public class Many2ManySaveClient {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure("conf/hibernate.cfg.xml");
		conf.addAnnotatedClass(Artist.class);
		conf.addAnnotatedClass(Movie.class);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder();
		builder.applySettings(conf.getProperties());
		StandardServiceRegistry serviceRegistry = builder.build();
		SessionFactory sf = conf.buildSessionFactory(serviceRegistry);
		
		//SessionFactory sf = conf.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Movie m1 = new Movie(1,"Adhurs",new TreeSet<Artist>());
		Movie m2 = new Movie(2,"Billa",new TreeSet<Artist>());
		
		Artist a1 = new Artist(1,"NTR");
		Artist a2 = new Artist(2,"Ajit");
		Artist a3 = new Artist(3,"Ntara");
		
		m1.getArtists().add(a1);
		m1.getArtists().add(a3);
		m2.getArtists().add(a2);
		m2.getArtists().add(a3);
		
		a1.setMovies(new TreeSet<Movie>());
		a2.setMovies(new TreeSet<Movie>());
		a3.setMovies(new TreeSet<Movie>());
		
		a1.getMovies().add(m1);
		a2.getMovies().add(m2);
		a3.getMovies().add(m1);
		a3.getMovies().add(m2);
		
		session.saveOrUpdate(a1);
		session.saveOrUpdate(a2);
		session.saveOrUpdate(a3);
		
		
		tr.commit();
		
		session.close();
		System.out.println("Saved Sucessfully");
		
		

	}

}
